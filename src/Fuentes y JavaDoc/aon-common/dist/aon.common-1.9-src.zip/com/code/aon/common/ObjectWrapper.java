package com.code.aon.common;

/**
 * TODO
 * @author Consulting & Development.
 *
 */

public class ObjectWrapper {
	
	private Object object;
	
	/**
	 * TODO
	 * @param object
	 */
	public ObjectWrapper(Object object){
		this.object = object;
	}

	/**
	 * TODO
	 * @return Object
	 */
	public Object getObject() {
		return object;
	}

	/**
	 * TODO
	 * @param object
	 */
	public void setObject(Object object) {
		this.object = object;
	}
	
}