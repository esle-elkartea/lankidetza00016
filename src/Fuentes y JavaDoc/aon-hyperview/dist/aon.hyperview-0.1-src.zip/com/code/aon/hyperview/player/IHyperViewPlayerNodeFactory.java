package com.code.aon.hyperview.player;


public interface IHyperViewPlayerNodeFactory {

	IHyperViewPlayerNode newTreeNode(String id, Object userObject);
	
}