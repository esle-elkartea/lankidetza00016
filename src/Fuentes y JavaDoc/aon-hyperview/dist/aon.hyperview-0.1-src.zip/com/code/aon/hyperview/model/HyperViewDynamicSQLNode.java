package com.code.aon.hyperview.model;


public class HyperViewDynamicSQLNode extends HyperViewSQLNode {
	
	public boolean isListView() {
		return false;
	}

	public boolean isFormView() {
		return false;
	}
	public boolean isImageView() {
		return false;
	}
	
}
